package auca.ac.rw.smartAgritech.model;

import java.util.List;
import jakarta.persistence.*;

@Entity
@Table(name = "pesticide")
public class Pesticide {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String pesticideName;    // e.g. "Roundup", "Karate"
    private String type;             // e.g. "Herbicide", "Insecticide"
    private String manufacturer;
    private Double pricePerLiter;

    // Other side of Many-to-Many — mappedBy means Crop manages the join table
    @ManyToMany(mappedBy = "pesticides")
    private List<Crop> crops;

    // ── Getters and Setters ──────────────────────────────────────
    public Long getId() { return this.id; }
    public void setId(Long id) { this.id = id; }

    public String getPesticideName() { return this.pesticideName; }
    public void setPesticideName(String n) { this.pesticideName = n; }

    public String getType() { return this.type; }
    public void setType(String type) { this.type = type; }

    public String getManufacturer() { return this.manufacturer; }
    public void setManufacturer(String m) { this.manufacturer = m; }

    public Double getPricePerLiter() { return this.pricePerLiter; }
    public void setPricePerLiter(Double p) { this.pricePerLiter = p; }

    public List<Crop> getCrops() { return this.crops; }
    public void setCrops(List<Crop> crops) { this.crops = crops; }
}