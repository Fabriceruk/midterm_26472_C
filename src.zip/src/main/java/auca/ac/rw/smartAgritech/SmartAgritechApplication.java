package auca.ac.rw.smartAgritech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.persistence.autoconfigure.EntityScan;

@SpringBootApplication
public class SmartAgritechApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartAgritechApplication.class, args);
	}

}
