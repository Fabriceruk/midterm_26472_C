package auca.ac.rw.smartAgritech.model;

import java.util.UUID;
import jakarta.persistence.*;

@Entity
@Table(name = "location")
public class Location {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    private String code;   // e.g. "KGL", "NOR"

    private String name;   // e.g. "Kigali", "Gasabo"

    @Enumerated(EnumType.STRING)
    private ELocationType type;  // PROVINCE, DISTRICT, SECTOR...

    // Self-referencing: a Location can have a parent Location
    // DISTRICT parent = PROVINCE, SECTOR parent = DISTRICT, etc.
    @ManyToOne
    @JoinColumn(name = "parent_id")
    private Location parent;

    // ── Getters and Setters ──────────────────────────────────────
    public UUID getId() { return this.id; }
    public void setId(UUID id) { this.id = id; }

    public String getCode() { return this.code; }
    public void setCode(String code) { this.code = code; }

    public String getName() { return this.name; }
    public void setName(String name) { this.name = name; }

    public ELocationType getType() { return this.type; }
    public void setType(ELocationType type) { this.type = type; }

    public Location getParent() { return this.parent; }
    public void setParent(Location parent) { this.parent = parent; }
}